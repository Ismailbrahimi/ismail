import java.util.Scanner;

public class Exercice4 {

	public static void main(String[] args) {
		final double MIN= 1 ;
		Scanner inp = new Scanner(System.in);
		final double MAX = inp.nextDouble();
		//Une fois la variable est assign� on ne pourra pas l'a modifi�
		//MAX=MIN+10 ;
		/*
		 * Pour C/C++;
		 * Une fois la variable est declar�e constante
		 * Il faut l'affecte un valeur d�s sa declaration
		 * Cette affecation est faite par le programmeur
		 * 
		 * */

	}

}
