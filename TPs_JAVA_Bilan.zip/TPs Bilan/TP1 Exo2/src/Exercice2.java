
public class Exercice2 {

	public static void main(String[] args) {
		Carre c = new Carre();
		System.out.println(c.surface());

	}

}
